#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan, PointCloud2, PointField
from ydlidar_x2 import YDLidarX2
import time
import struct
import math

class CustomLaserScan(LaserScan):
    def __init__(self):
        super().__init__()
        self.region_a = 0.0
        self.region_b = 0.0
        self.region_c = 0.0

class LidarPublisher:
    def __init__(self, port):
        self.lidar = YDLidarX2(port)
        self.lidar.connect()
        self.lidar.start_scan()

        # Create ROS publishers
        self.lidar_scan_pub = rospy.Publisher('/lidar_scan', CustomLaserScan, queue_size=10)
        self.pointcloud_pub = rospy.Publisher('/lidar_pointcloud', PointCloud2, queue_size=10)
        self.velocity_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)  # New publisher for velocity
        rospy.init_node('lidar_publisher', anonymous=True)

    def run(self):
        try:
            while not rospy.is_shutdown():
                if self.lidar.available:
                    distances = self.lidar.get_data()
                    region_a, region_b, region_c = self.publish_laser_scan(distances)
                    
                    # Check if region_b is greater than 250 and publish linear velocity accordingly
                    if region_b<250:
                        self.publish_velocity(-3.36,0.00)
                    #elif 250<region_b>300:
                        #self.publish_velocity(0.0, -10.0)  # Linear velocity is 10, angular velocity is 0
                        #if region_a > 250:
                        #    self.publish_velocity(0.0, -5.0)
                        #    if region_a > 300:
                        #        self.publish_velocity(0.0, 5.0)
                        #        if region_c > 250:
                        #            self.publish_velocity(0.0, 5.0)
                    else:
                        self.publish_velocity(3.36, 0.0)  # Linear velocity is 0, angular velocity is 5

                    self.publish_pointcloud(distances)
                time.sleep(0.1)
        except rospy.ROSInterruptException:
            pass

    def calculate_regions(self, distances):
        region_a = min(distances[0:120])
        region_b = min(distances[121:240])
        region_c = min(distances[241:360])
        return region_a, region_b, region_c

    def publish_laser_scan(self, distances):
        region_a, region_b, region_c = self.calculate_regions(distances)
        
        scan_msg = CustomLaserScan()
        scan_msg.header.stamp = rospy.Time.now()
        scan_msg.header.frame_id = 'lidar_frame'
        scan_msg.angle_min = 0.0
        scan_msg.angle_max = 2 * math.pi
        scan_msg.angle_increment = math.pi / 180.0
        scan_msg.time_increment = 1.0 / 360.0
        scan_msg.range_min = 0.01
        scan_msg.range_max = 8.0  # Set according to your lidar's specifications

        scan_msg.ranges = distances
        scan_msg.region_a = region_a
        scan_msg.region_b = region_b
        scan_msg.region_c = region_c
        self.lidar_scan_pub.publish(scan_msg)

        print(f"Region A: {region_a}\nRegion B: {region_b}\nRegion C: {region_c}")

        return region_a, region_b, region_c

    def publish_pointcloud(self, distances):
        pcl_msg = PointCloud2()
        pcl_msg.header.stamp = rospy.Time.now()
        pcl_msg.header.frame_id = 'lidar_frame'

        pcl_msg.height = 1
        pcl_msg.width = len(distances)
        pcl_msg.is_dense = False

        pcl_msg.fields.append(PointField(
            name="x", offset=0, datatype=PointField.FLOAT32, count=1))
        pcl_msg.fields.append(PointField(
            name="y", offset=4, datatype=PointField.FLOAT32, count=1))
        pcl_msg.fields.append(PointField(
            name="z", offset=8, datatype=PointField.FLOAT32, count=1))

        point_data = []
        for i, dist in enumerate(distances):
            if dist < self.lidar.out_of_range:
                angle = i * math.pi / 180.0
                x = dist * math.cos(angle)
                y = dist * math.sin(angle)
                z = 0.0  # You may need to adjust this based on your LiDAR mounting height
                point_data.extend([x, y, z])

        pcl_msg.data = struct.pack('f' * len(point_data), *point_data)
        self.pointcloud_pub.publish(pcl_msg)

    def publish_velocity(self, linear_vel, angular_vel):
        twist_msg = Twist()
        twist_msg.linear.x = linear_vel
        twist_msg.angular.z = angular_vel
        self.velocity_pub.publish(twist_msg)

if __name__ == "__main__":
    try:
        port = '/dev/ttyUSB0'  # Change this to the correct port
        lidar_publisher = LidarPublisher(port)

        lidar_publisher.run()

    except rospy.ROSInterruptException:
        pass
